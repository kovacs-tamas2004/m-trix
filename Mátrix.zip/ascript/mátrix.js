let szamok = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
let divs = document.getElementsByClassName("doboz");

function legyenVeletlenSorrend(tomb){
    let hossz = tomb.length;

    for (let i = 0; i < hossz; i++) {
        let index = Math.floor(Math.random() * tomb.length);
        tomb.splice(index, 1);
    }
}

let veletlen = ["3", "6", "1", "8", "5", "2", "4", "9", "7"];
let megjelenik = ["", "", "", "", "", "", "", "", ""];

function megjelenit(){
    let tartalom = "";
    for(let i = 0; i < szamok.length; i++){
        tartalom += `
        <div class="doboz" onclick="getNumber${i}()">

            ${megjelenik[i]} 
        </div>`;
    }

    document.getElementById("main").innerHTML = tartalom;
    
}

function getNumber0(){
    
    megjelenik[0] = veletlen[0];
    
    megjelenit();
}

function getNumber1(){
    
    megjelenik[1] = veletlen[1];
    megjelenit();
}

function getNumber2(){
    
    megjelenik[2] = veletlen[2];
    megjelenit();
}

function getNumber3(){
    
    megjelenik[3] = veletlen[3];
    megjelenit();
}

function getNumber4(){
    
    megjelenik[4] = veletlen[4];
    megjelenit();
}

function getNumber5(){
    
    megjelenik[5] = veletlen[5];
    megjelenit();
}

function getNumber6(){
    
    megjelenik[6] = veletlen[6];
    megjelenit();
}

function getNumber7(){
    
    megjelenik[7] = veletlen[7];
    megjelenit();
}

function getNumber8(){
    
    megjelenik[8] = veletlen[8];
    megjelenit();
}

function Torles(){
    veletlen = ["3", "6", "1", "8", "5", "2", "4", "9", "7"];
    megjelenik = ["", "", "", "", "", "", "", "", ""];
    megjelenit();
}

megjelenit();

// divs.array.forEach(element => {
//     divs.clickAddEventListener();
//     element.textContent
// });

